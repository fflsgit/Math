X = [41, 48, 41, 49, 57;
    65, 57, 54, 72, 64;
    45, 51, 56, 48, 48]
n = numel(X)

Ti = sum(X,2)
xBar = mean(X,2)
sumX2i = sum(X.^2,2)
sumX2 = sum(sumX2i)

T = sum(Ti)
meanT = T/numel(T)

C = T^2/n

SST = sumX2-C
sum(Ti.^2/size(X,2))
SSA = sum(Ti.^2/size(X,2))-C
SSE = SST-SSA

r = size(X,1)
MSA = SSA/(r-1)
MSE = SSE/(n-r)

F = MSA/MSE
%%
a = [4,5,6]
p = [0.1,0.2,0.7]
EX = a*p'
EX2 = a.^2*p'
DX = EX2-EX^2




a=[49.6, 49.3, 50.1, 50.0, 49.2, 49.9, 49.8, 51.0, 50.2];
n = numel(a);
meanA = mean(a)
% varA = var(a)
cA = sum((a-meanA).^2)/(n-1)
t = (meanA-50)/(sqrt(xiuA)/sqrt(n))